import { SYMS, TFS, BOOK, analyze, loadCandles, money, fmtPx } from './engine.js';
import { mountChart } from './chart.js';

const $ = (id) => document.getElementById(id);
const KEY = 'alladinn_v1';

const state = {
  sym: SYMS[0].id,
  tf: 3600,
  strat: 'macro',
  candles: [],
  live: false,
  result: null,
  radar: [],
  paper: { bal: 100000, start: 100000, day: null, dayPnl: 0, trades: [], open: [], eq: [100000] },
  riskPct: 0.5,
  dayLoss: 2,
  cross: true
};

try {
  const saved = JSON.parse(localStorage.getItem(KEY) || 'null');
  if (saved) {
    if (SYMS.some((s) => s.id === saved.sym)) state.sym = saved.sym;
    if (TFS.some((t) => t.sec === saved.tf)) state.tf = saved.tf;
    if (saved.strat) state.strat = saved.strat;
    if (saved.paper && saved.paper.bal > 0) state.paper = { ...state.paper, ...saved.paper, open: saved.paper.open || [] };
    if (saved.riskPct) state.riskPct = saved.riskPct;
    if (saved.dayLoss) state.dayLoss = saved.dayLoss;
  }
} catch (e) {}

function save() {
  const slim = {
    sym: state.sym, tf: state.tf, strat: state.strat, riskPct: state.riskPct, dayLoss: state.dayLoss,
    paper: { ...state.paper, eq: state.paper.eq.slice(-200), trades: state.paper.trades.slice(-80) }
  };
  try { localStorage.setItem(KEY, JSON.stringify(slim)); } catch (e) {}
}

const chart = mountChart($('cv'));
chart.onLegend = (c) => {
  if (!c) { $('legend').textContent = ''; return; }
  const sym = cur();
  const dir = c.c >= c.o ? 'up' : 'dn';
  $('legend').innerHTML = '<span class="' + dir + '">O ' + fmtPx(c.o, sym.dec) + '  H ' + fmtPx(c.h, sym.dec) + '  L ' + fmtPx(c.l, sym.dec) + '  C ' + fmtPx(c.c, sym.dec) + '</span>';
};

function cur() { return SYMS.find((s) => s.id === state.sym) || SYMS[0]; }
function stratMeta() {
  for (const g of BOOK) for (const it of g.items) if (it[0] === state.strat) return { id: it[0], name: it[1], blurb: it[2], group: g.group };
  return { id: 'macro', name: 'Macro desk (strict)', blurb: '', group: 'ALLADINN macro' };
}

function buckets() {
  const o = {};
  state.paper.open.forEach((p) => {
    const s = SYMS.find((x) => x.id === p.sym);
    const b = s ? s.bucket : 'other';
    o[b] = (o[b] || 0) + 1;
  });
  return o;
}

function runAnalyze() {
  const sym = cur();
  state.result = analyze(state.candles, state.strat, {
    sym: sym.id, tf: state.tf, cls: sym.cls, bucket: sym.bucket, openBuckets: buckets()
  });
  paint();
}

function paint() {
  const sym = cur();
  const cs = state.candles;
  const last = cs[cs.length - 1];
  const prev = cs[cs.length - 2];
  $('symName').textContent = sym.name;
  $('symId').textContent = sym.id;
  if (last) {
    $('last').textContent = fmtPx(last.c, sym.dec);
    if (prev) {
      const d = last.c - prev.c;
      const pct = prev.c ? (d / prev.c) * 100 : 0;
      $('chg').className = 'chg ' + (d >= 0 ? 'up' : 'dn');
      $('chg').textContent = (d >= 0 ? '+' : '−') + fmtPx(Math.abs(d), sym.dec) + '   ' + (pct >= 0 ? '+' : '−') + Math.abs(pct).toFixed(2) + '%';
    }
  }
  const conn = $('conn');
  conn.textContent = state.live ? 'LIVE FEED' : 'SIM TAPE';
  conn.className = 'pill ' + (state.live ? 'live' : 'sim');
  const r = state.result;
  const bias = r ? r.bias : 0;
  $('biasPill').textContent = bias > 0 ? 'HTF up' : bias < 0 ? 'HTF down' : 'HTF flat';
  $('biasPill').className = 'pill ' + (bias > 0 ? 'live' : bias < 0 ? 'sell' : '');
  const meta = stratMeta();
  $('stratName').textContent = meta.name;
  $('stratSub').textContent = meta.group;
  chart.setData(cs, sym.dec);
  chart.setSignal(r && r.signal, r && r.ghost);
  paintPrism();
  paintMacro();
  paintRisk();
  save();
}

function paintPrism() {
  const r = state.result;
  const sym = cur();
  const box = $('prism');
  if (!r) { box.innerHTML = '<p class="mut">Loading the tape…</p>'; return; }
  const sig = r.signal;
  const ghost = r.ghost;
  if (sig) {
    const sideCls = sig.side === 'BUY' ? 'buy' : 'sell';
    box.innerHTML =
      '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><h2>' + sig.side + ' · ' + sig.score + '</h2><span class="pill ' + sideCls + '">' + (sig.kind === 'macro' ? 'CLEARED' : 'TACTICAL') + '</span></div>' +
      '<p class="kicker">' + sig.tag + (sig.scalar && sig.scalar < 1 ? ' · size ×' + sig.scalar.toFixed(2) + ' (vol hot)' : '') + '</p>' +
      levelsHtml(sig, sym) +
      '<div class="actions"><button id="arm" class="arm" type="button">Arm paper</button></div>';
    $('arm').onclick = () => arm(sig);
    return;
  }
  const why = (r.drops && r.drops[0]) || 'Desk is flat.';
  box.innerHTML =
    '<h2>Flat</h2><p class="kicker">No order. The desk would rather miss it.</p>' +
    (ghost ? levelsHtml(ghost, sym) : '') +
    '<p class="why">' + why + '</p>' +
    '<div class="actions"><button class="arm" type="button" disabled>Nothing cleared</button></div>';
}

function levelsHtml(sig, sym) {
  const risk = Math.abs(sig.entry - sig.sl);
  const rows = [
    ['Entry', fmtPx(sig.entry, sym.dec), ''],
    ['Stop', fmtPx(sig.sl, sym.dec), '−1.0R']
  ];
  (sig.tps || []).forEach((t, i) => rows.push(['TP' + (i + 1) + ' · ' + t.pct + '%', fmtPx(t.px, sym.dec), t.r + 'R']));
  return '<div class="levels">' + rows.map((row) => '<div class="lv"><span>' + row[0] + '</span><b>' + row[1] + (row[2] ? ' · ' + row[2] : '') + '</b></div>').join('') +
    '<p class="mut">Risk unit ' + fmtPx(risk, sym.dec) + '. ' + ((sig.tps && sig.tps[0] && sig.tps[0].note) || '') + '</p></div>';
}

function paintMacro() {
  const r = state.result;
  const gates = (r && r.gates) || [];
  $('gates').innerHTML = gates.length
    ? gates.map((g) => '<div class="gate ' + (g.ok ? 'ok' : 'no') + '"><i></i><div><b>' + g.name + '</b><div class="mut">' + g.detail + '</div></div></div>').join('')
    : '<p class="mut">Switch the strategy to Macro desk. Tactical books do not use this gate.</p>';
  const drops = (r && r.drops) || [];
  $('drops').innerHTML = drops.length ? drops.map((d) => '<div class="drop">' + d + '</div>').join('') : '<p class="mut">No drop on the current pass.</p>';
  if (r && r.vr) {
    $('drops').innerHTML += '<p class="mut">Variance ratio ' + r.vr.vr.toFixed(2) + ' · z ' + r.vr.z.toFixed(2) + (r.vol ? ' · vol ' + r.vol.toFixed(2) + '×' : '') + '</p>';
  }
}

function openRiskCash() {
  return state.paper.open.reduce((t, p) => t + (p.riskLeft || 0), 0);
}

function paintRisk() {
  const fl = state.paper.open.reduce((t, p) => t + (p.fl || 0), 0);
  const eq = state.paper.bal + fl;
  const net = eq - state.paper.start;
  $('eqb').textContent = money(eq);
  $('netb').textContent = (net >= 0 ? '+' : '') + money(net);
  $('netb').className = net >= 0 ? 'up' : 'dn';
  $('riskb').textContent = money(openRiskCash());
  const n = state.paper.trades.length;
  const w = state.paper.trades.filter((t) => t.pnl > 0).length;
  $('winb').textContent = n ? Math.round(100 * w / n) + '% · ' + n : '—';
  const px = lastPx();
  const sym = cur();
  const sig = state.result && state.result.signal;
  if (sig && px) {
    const dist = Math.abs(sig.entry - sig.sl) || 1;
    const dol = eq * (state.riskPct / 100) * (sig.scalar || 1);
    const qty = dol / dist;
    $('sizeNote').textContent = 'If this signal is armed: risk ' + money(dol) + ' · about ' + qty.toFixed(sym.dec > 3 ? 0 : 4) + ' units · stop distance ' + fmtPx(dist, sym.dec) + '. No added leverage.';
  } else $('sizeNote').textContent = 'Size comes from the stop, not from a feeling. Hot volatility cuts the macro size. Cap is 1×, never more.';
  $('positions').innerHTML = state.paper.open.map((p, i) => {
    const s = SYMS.find((x) => x.id === p.sym) || sym;
    return '<div class="lv"><span>' + p.side + ' ' + s.name + ' · ' + p.tf + '<br><small class="mut">' + p.tag + '</small></span><b class="' + ((p.fl || 0) >= 0 ? 'up' : 'dn') + '">' + money(p.fl || 0) + '<br><button data-i="' + i + '" class="tool close" type="button">Close</button></b></div>';
  }).join('') || '<p class="mut">No open paper risk.</p>';
  $('positions').querySelectorAll('.close').forEach((b) => b.onclick = () => closeAt(Number(b.dataset.i), false));
  drawEq();
}

function drawEq() {
  const cv = $('eq');
  const dpr = Math.min(2, devicePixelRatio || 1);
  const w = cv.clientWidth || 300;
  cv.width = w * dpr; cv.height = 72 * dpr;
  const x = cv.getContext('2d');
  x.setTransform(dpr, 0, 0, dpr, 0, 0);
  const pts = state.paper.eq.slice(-80);
  if (pts.length < 2) return;
  const mn = Math.min(...pts), mx = Math.max(...pts), sp = (mx - mn) || 1;
  x.beginPath();
  pts.forEach((v, i) => {
    const X = i / (pts.length - 1) * w, Y = 8 + (mx - v) / sp * 56;
    i ? x.lineTo(X, Y) : x.moveTo(X, Y);
  });
  x.strokeStyle = pts[pts.length - 1] >= state.paper.start ? '#3ee0a2' : '#ff5d73';
  x.lineWidth = 2;
  x.stroke();
}

function lastPx() {
  const c = state.candles[state.candles.length - 1];
  return c ? c.c : 0;
}

function toast(msg) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.add('on');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove('on'), 2800);
}

function dayKey(ts) { return new Date((ts || Date.now() / 1000) * 1000).toISOString().slice(0, 10); }

function arm(sig) {
  const sym = cur();
  const px = lastPx();
  if (!px) return;
  const today = dayKey(state.candles.at(-1).t);
  if (state.paper.day !== today) { state.paper.day = today; state.paper.dayPnl = 0; }
  const eq = state.paper.bal;
  if (state.paper.dayPnl <= -(state.dayLoss / 100) * eq) return toast('Daily loss stop is hit. No new risk today.');
  if (state.paper.open.length >= 6) return toast('Six open risks is the book cap.');
  const dist = Math.abs(sig.entry - sig.sl);
  if (!(dist > 0)) return;
  const dol = eq * (state.riskPct / 100) * (sig.scalar || 1);
  const qty = dol / dist;
  state.paper.open.push({
    sym: sym.id, side: sig.side, tf: TFS.find((t) => t.sec === state.tf).id,
    entry: sig.entry, sl: sig.sl, tps: sig.tps, qty, qty0: qty, tag: sig.tag,
    riskLeft: dol, hit: 0, born: state.candles.length, fl: 0, bars: 0
  });
  toast(sig.side + ' armed · risk ' + money(dol));
  markToMarket();
  paintRisk();
  save();
}

function closeAt(i, reason) {
  const p = state.paper.open[i];
  if (!p) return;
  const px = p.sym === cur().id ? lastPx() : p.entry;
  realize(p, px, reason || 'MANUAL');
  state.paper.open.splice(i, 1);
  paint();
}

function realize(p, px, type) {
  const dir = p.side === 'BUY' ? 1 : -1;
  const pnl = p.qty * dir * (px - p.entry);
  state.paper.bal += pnl;
  state.paper.dayPnl += pnl;
  state.paper.eq.push(state.paper.bal);
  state.paper.trades.push({ sym: p.sym, side: p.side, pnl, type, t: Date.now() });
  toast(type + ' ' + (pnl >= 0 ? '+' : '') + money(pnl));
}

function markToMarket() {
  const px = lastPx();
  const sym = cur().id;
  const still = [];
  state.paper.open.forEach((p) => {
    if (p.sym !== sym || !px) { still.push(p); return; }
    const dir = p.side === 'BUY' ? 1 : -1;
    p.fl = p.qty * dir * (px - p.entry);
    const stopHit = dir > 0 ? px <= p.sl : px >= p.sl;
    if (stopHit) {
      realize(p, p.sl, p.hit ? 'BE' : 'STOP');
      return;
    }
    while (p.tps && p.hit < p.tps.length && (dir > 0 ? px >= p.tps[p.hit].px : px <= p.tps[p.hit].px)) {
      const tp = p.tps[p.hit];
      const cut = p.qty0 * (tp.pct / 100);
      const part = Math.min(p.qty, cut);
      const pnl = part * dir * (tp.px - p.entry);
      p.qty -= part;
      state.paper.bal += pnl;
      state.paper.dayPnl += pnl;
      state.paper.trades.push({ sym: p.sym, side: p.side, pnl, type: 'TP' + (p.hit + 1), t: Date.now() });
      p.hit++;
      if (p.hit === 1) { p.sl = p.entry; p.riskLeft = 0; }
      toast('TP' + p.hit + ' filled ' + money(pnl));
    }
    if (p.qty <= p.qty0 * 0.02) return;
    still.push(p);
  });
  state.paper.open = still;
  const fl = state.paper.open.reduce((t, p) => t + (p.sym === sym ? p.fl || 0 : 0), 0);
  const lastEq = state.paper.eq[state.paper.eq.length - 1];
  const nowEq = state.paper.bal + fl;
  if (Math.abs(nowEq - lastEq) > 0.01) state.paper.eq.push(nowEq);
  if (state.paper.eq.length > 400) state.paper.eq.shift();
}

async function reload() {
  const sym = cur();
  $('conn').textContent = 'LINKING';
  const pack = await loadCandles(sym, state.tf);
  breathe(pack);
  state.candles = pack.candles;
  state.live = pack.live;
  markToMarket();
  runAnalyze();
}

function buildTf() {
  $('tfbar').innerHTML = TFS.map((t) => '<button type="button" data-tf="' + t.sec + '"' + (t.sec === state.tf ? ' class="on"' : '') + '>' + t.id + '</button>').join('');
}
$('tfbar').onclick = (e) => {
  const b = e.target.closest('button');
  if (!b) return;
  state.tf = +b.dataset.tf;
  buildTf();
  reload();
};

function show(tab) {
  document.querySelectorAll('.view').forEach((v) => v.classList.toggle('on', v.id === 'view-' + tab));
  document.querySelectorAll('#nav button').forEach((b) => b.classList.toggle('on', b.dataset.tab === tab));
  if (tab === 'chart') requestAnimationFrame(() => chart.resize());
}
$('nav').onclick = (e) => {
  const b = e.target.closest('button');
  if (b) show(b.dataset.tab);
};

$('zin').onclick = () => chart.zoom(1);
$('zout').onclick = () => chart.zoom(-1);
$('zreset').onclick = () => chart.reset();
$('xhair').onclick = () => {
  state.cross = !state.cross;
  $('xhair').classList.toggle('on', state.cross);
  chart.setCross(state.cross);
};

function fillSym() {
  $('symList').innerHTML = SYMS.map((s) => '<button type="button" data-id="' + s.id + '"' + (s.id === state.sym ? ' class="on"' : '') + '><b>' + s.name + '</b><div class="mut">' + s.id + ' · ' + s.cls + '</div></button>').join('');
}
$('symBtn').onclick = () => { fillSym(); $('symDlg').showModal(); };
$('symX').onclick = () => $('symDlg').close();
$('symList').onclick = (e) => {
  const b = e.target.closest('button');
  if (!b) return;
  state.sym = b.dataset.id;
  $('symDlg').close();
  reload();
};

function fillStrat() {
  $('stList').innerHTML = BOOK.map((g) => '<div class="mut" style="margin-top:8px">' + g.group + '</div>' + g.items.map((it) =>
    '<button type="button" data-id="' + it[0] + '"' + (it[0] === state.strat ? ' class="on"' : '') + '><b>' + it[1] + '</b><div class="mut">' + it[2] + '</div></button>'
  ).join('')).join('');
}
$('stratBtn').onclick = () => { fillStrat(); $('stDlg').showModal(); };
$('stX').onclick = () => $('stDlg').close();
$('stList').onclick = (e) => {
  const b = e.target.closest('button');
  if (!b || !b.dataset.id) return;
  state.strat = b.dataset.id;
  $('stDlg').close();
  runAnalyze();
};

$('book').innerHTML = BOOK.map((g) => '<details class="glass"' + (g.group.startsWith('ALLADINN') ? ' open' : '') + '><summary>' + g.group + '</summary><div style="padding:0 10px 10px">' +
  g.items.map((it) => '<button class="srow' + (it[0] === state.strat ? ' on' : '') + '" data-id="' + it[0] + '" type="button"><b>' + it[1] + '</b><span>' + it[2] + '</span></button>').join('') +
  '</div></details>').join('');
$('book').onclick = (e) => {
  const b = e.target.closest('.srow');
  if (!b) return;
  state.strat = b.dataset.id;
  document.querySelectorAll('.srow').forEach((x) => x.classList.toggle('on', x.dataset.id === state.strat));
  runAnalyze();
  show('chart');
};

$('scan').onclick = async () => {
  $('radar').innerHTML = '<p class="mut">Reading six books…</p>';
  const rows = [];
  for (const sym of SYMS) {
    const pack = sym.id === state.sym && state.candles.length ? { candles: state.candles, live: state.live } : await loadCandles(sym, state.tf);
    const res = analyze(pack.candles, state.strat, { sym: sym.id, tf: state.tf, cls: sym.cls, bucket: sym.bucket, openBuckets: buckets() });
    rows.push({ sym, res });
  }
  state.radar = rows;
  $('radar').innerHTML = rows.map((row) => {
    const sig = row.res.signal;
    const why = (row.res.drops && row.res.drops[0]) || 'Flat';
    const right = sig ? '<b class="' + (sig.side === 'BUY' ? 'up' : 'dn') + '">' + sig.side + ' ' + sig.score + '</b>' : '<b class="mut">DROP</b>';
    return '<button class="lv" data-id="' + row.sym.id + '" type="button" style="width:100%;margin-top:6px"><span>' + row.sym.name + '<br><small class="mut">' + (sig ? sig.tag : why) + '</small></span>' + right + '</button>';
  }).join('');
};
$('radar').onclick = (e) => {
  const b = e.target.closest('button');
  if (!b) return;
  state.sym = b.dataset.id;
  show('chart');
  reload();
};

$('riskPct').value = state.riskPct;
$('dayLoss').value = state.dayLoss;
$('riskPct').onchange = () => { state.riskPct = Math.max(0.1, Math.min(2, +$('riskPct').value || 0.5)); paintRisk(); save(); };
$('dayLoss').onchange = () => { state.dayLoss = Math.max(0.5, Math.min(10, +$('dayLoss').value || 2)); save(); };
$('resetBook').onclick = () => {
  state.paper = { bal: 100000, start: 100000, day: null, dayPnl: 0, trades: [], open: [], eq: [100000] };
  toast('Paper book reset');
  paint();
};

function tickClock() {
  $('clock').textContent = 'UTC ' + new Date().toISOString().slice(11, 19);
}
setInterval(tickClock, 1000);
tickClock();

function breathe(pack) {
  if (!pack || pack.live || !pack.candles.length) return;
  const last = pack.candles[pack.candles.length - 1];
  const span = Math.max(Math.abs(last.h - last.l), last.c * 0.0008);
  last.c = last.o + Math.sin(Date.now() / 2800) * span * 0.45;
  last.h = Math.max(last.h, last.c);
  last.l = Math.min(last.l, last.c);
}

async function poll() {
  if (document.hidden) return;
  const sym = cur();
  const pack = await loadCandles(sym, state.tf);
  if (!pack.candles.length) return;
  breathe(pack);
  const prev = state.candles.length ? state.candles[state.candles.length - 1].c : 0;
  state.candles = pack.candles;
  state.live = pack.live;
  if (pack.candles[pack.candles.length - 1].c !== prev) {
    markToMarket();
    runAnalyze();
  }
}
setInterval(poll, 15000);

addEventListener('resize', () => chart.resize());
if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
  navigator.serviceWorker.register('sw.js').catch(() => {});
}

buildTf();
reload();
