/* ALLADINN engine — strategies, targets, macro gates.
   Candles are {t,o,h,l,c,v}. Signals read the last CLOSED candle only. */

export const TFS = [
  { id: '1m', sec: 60, bin: '1m' },
  { id: '5m', sec: 300, bin: '5m' },
  { id: '15m', sec: 900, bin: '15m' },
  { id: '30m', sec: 1800, bin: '30m' },
  { id: '1h', sec: 3600, bin: '1h' },
  { id: '4h', sec: 14400, bin: '4h' },
  { id: '1D', sec: 86400, bin: '1d' },
  { id: '1W', sec: 604800, bin: '1w' }
];

export const SYMS = [
  { id: 'BTCUSDT', name: 'Bitcoin', cls: 'crypto', dec: 1, seed: 64250, bucket: 'crypto' },
  { id: 'ETHUSDT', name: 'Ethereum', cls: 'crypto', dec: 2, seed: 3180, bucket: 'crypto' },
  { id: 'SOLUSDT', name: 'Solana', cls: 'crypto', dec: 2, seed: 148, bucket: 'crypto' },
  { id: 'PAXGUSDT', name: 'Gold', cls: 'metal', dec: 2, seed: 4125, bucket: 'metal' },
  { id: 'EURUSDT', name: 'EUR/USD', cls: 'forex', dec: 5, seed: 1.0862, bucket: 'fx' },
  { id: 'BNBUSDT', name: 'BNB', cls: 'crypto', dec: 2, seed: 605, bucket: 'crypto' }
];

const REPLAY = new Map();

export function atr(cs, n = 14) {
  if (!cs || cs.length < 3) return 0;
  const a = cs.slice(-(n + 1));
  let s = 0;
  for (let i = 1; i < a.length; i++) {
    const c = a[i], p = a[i - 1];
    s += Math.max(c.h - c.l, Math.abs(c.h - p.c), Math.abs(c.l - p.c));
  }
  return s / Math.max(1, a.length - 1);
}

export function swings(cs, k = 2) {
  const H = [], W = [];
  for (let i = k; i < cs.length - k; i++) {
    let hi = true, lo = true;
    for (let j = i - k; j <= i + k; j++) {
      if (j === i) continue;
      if (cs[j].h > cs[i].h) hi = false;
      if (cs[j].l < cs[i].l) lo = false;
    }
    if (hi) H.push(i);
    if (lo) W.push(i);
  }
  return { H, W };
}

export function aggregate(cs, factor) {
  if (!cs.length || factor <= 1) return cs.slice();
  const step = (cs.length > 1 ? cs[1].t - cs[0].t : 60) || 60;
  const span = step * factor;
  const o = [];
  for (const c of cs) {
    const b = Math.floor(c.t / span) * span;
    const l = o[o.length - 1];
    if (l && l.t === b) {
      l.h = Math.max(l.h, c.h);
      l.l = Math.min(l.l, c.l);
      l.c = c.c;
      l.v = (l.v || 0) + (c.v || 0);
    } else o.push({ t: b, o: c.o, h: c.h, l: c.l, c: c.c, v: c.v || 0 });
  }
  return o;
}

export function biasOf(cs) {
  if (!cs || cs.length < 20) return 0;
  const { H, W } = swings(cs, 3);
  if (H.length < 2 || W.length < 2) return 0;
  const h1 = cs[H[H.length - 1]].h, h0 = cs[H[H.length - 2]].h;
  const l1 = cs[W[W.length - 1]].l, l0 = cs[W[W.length - 2]].l;
  if (h1 > h0 && l1 > l0) return 1;
  if (h1 < h0 && l1 < l0) return -1;
  return 0;
}

function avgRange(cs) {
  if (!cs.length) return 0;
  return cs.reduce((t, c) => t + (c.h - c.l), 0) / cs.length;
}

export function vratio(cs, q = 4) {
  const n = cs.length;
  const K = Math.min(n - 1, 160);
  if (K < 60) return { vr: 1, z: 0, thin: true };
  const r = [];
  for (let i = n - K; i < n; i++) {
    const prev = cs[i - 1].c;
    r.push(prev > 0 ? Math.log(cs[i].c / prev) : 0);
  }
  const m = r.reduce((t, x) => t + x, 0) / r.length;
  const v1 = r.reduce((t, x) => t + (x - m) * (x - m), 0) / r.length;
  let s = 0, c = 0;
  for (let i = q - 1; i < r.length; i++) {
    let acc = 0;
    for (let j = 0; j < q; j++) acc += r[i - j] - m;
    s += acc * acc;
    c++;
  }
  const vr = v1 > 0 ? (s / c) / (q * v1) : 1;
  const z = (vr - 1) / Math.sqrt((2 * (2 * q - 1) * (q - 1)) / (3 * q * r.length));
  return { vr, z, thin: false };
}

function body(c) { return Math.abs(c.c - c.o); }
function rng(c) { return (c.h - c.l) || 1e-12; }
function bull(c) { return c.c >= c.o; }
function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

function Q(c, a, side, sl, q, tag) {
  if (!(Math.abs(c.c - sl) > 0)) return null;
  const stop = side === 'BUY' ? Math.min(sl, c.c - a * 0.08) : Math.max(sl, c.c + a * 0.08);
  if (side === 'BUY' && !(stop < c.c)) return null;
  if (side === 'SELL' && !(stop > c.c)) return null;
  const capped = side === 'BUY' ? Math.max(stop, c.c - 3.2 * a) : Math.min(stop, c.c + 3.2 * a);
  return { side, entry: c.c, sl: capped, q: clamp(q, 12, 40), tag };
}

function msnr(cs) {
  const A = [], V = [];
  for (let i = 1; i < cs.length - 1; i++) {
    const p = cs[i - 1].c, c = cs[i].c, n = cs[i + 1].c;
    if (c > p && c > n) {
      let fresh = true;
      for (let j = i + 2; j < cs.length; j++) if (cs[j].h >= c) { fresh = false; break; }
      if (fresh) A.push(c);
    } else if (c < p && c < n) {
      let fresh = true;
      for (let j = i + 2; j < cs.length; j++) if (cs[j].l <= c) { fresh = false; break; }
      if (fresh) V.push(c);
    }
  }
  return { A: A.slice(-8), V: V.slice(-8) };
}

function orderBlock(cs, ctx) {
  const a = ctx.atr, c = cs[cs.length - 1];
  if (!a) return null;
  for (let i = cs.length - 5; i >= Math.max(2, cs.length - 48); i--) {
    const ob = cs[i - 1], d = cs[i];
    if (body(d) < 0.85 * a) continue;
    if (d.c > d.o && ob.c < ob.o && d.c > ob.h) {
      let dead = false;
      for (let j = i + 1; j < cs.length - 1; j++) if (cs[j].l < ob.l) { dead = true; break; }
      if (dead) continue;
      if (c.l <= ob.h && c.c > ob.h && bull(c))
        return Q(c, a, 'BUY', ob.l - a * 0.12, 24, 'Bullish order block');
    }
    if (d.c < d.o && ob.c > ob.o && d.c < ob.l) {
      let dead = false;
      for (let j = i + 1; j < cs.length - 1; j++) if (cs[j].h > ob.h) { dead = true; break; }
      if (dead) continue;
      if (c.h >= ob.l && c.c < ob.l && !bull(c))
        return Q(c, a, 'SELL', ob.h + a * 0.12, 24, 'Bearish order block');
    }
  }
  return null;
}

function confluence(cs, ctx) {
  if (ctx.cls === 'metal') {
    const h = new Date(ctx.now * 1000).getUTCHours();
    if (h < 13 || h >= 17) return { block: 'Metals confluence only 13:00–17:00 UTC (BZR window).' };
  }
  if (!ctx.bias) return { block: 'Confluence stands aside when the higher-timeframe bias is flat.' };
  const s = orderBlock(cs, ctx);
  if (!s || s.block) return s;
  if ((s.side === 'BUY' && ctx.bias < 0) || (s.side === 'SELL' && ctx.bias > 0))
    return { block: 'Order block fights the higher-timeframe bias.' };
  const lv = msnr(cs), a = ctx.atr;
  const pool = s.side === 'SELL' ? lv.A : lv.V;
  const near = pool.some((x) => Math.abs(x - (s.side === 'BUY' ? Math.max(s.sl, s.entry - a) : Math.min(s.sl, s.entry + a))) <= a * 0.85);
  if (!near) return { block: 'Order block is not sitting on a fresh MSNR level.' };
  return { ...s, q: Math.min(40, s.q + 8), tag: 'OB + fresh MSNR' };
}

function msnrOb(cs, ctx) {
  const s = orderBlock(cs, ctx);
  if (!s || s.block) return s;
  const lv = msnr(cs), a = ctx.atr;
  const pool = s.side === 'SELL' ? lv.A : lv.V;
  if (!pool.some((x) => Math.abs(x - s.entry) <= a * 0.9)) return null;
  return { ...s, q: s.q + 4, tag: 'MSNR + order block' };
}

function fvg(cs, ctx) {
  const a = ctx.atr, n = cs.length, c = cs[n - 1];
  for (let i = n - 3; i >= Math.max(2, n - 28); i--) {
    const x = cs[i - 2], m = cs[i - 1], y = cs[i];
    if (y.l - x.h > 0.25 * a && bull(m) && body(m) > 0.55 * a) {
      let open = true;
      for (let j = i + 1; j < n - 1; j++) if (cs[j].c < x.h) { open = false; break; }
      if (open && c.l <= y.l && c.c > (y.l + x.h) / 2 && bull(c))
        return Q(c, a, 'BUY', Math.min(c.l, x.h) - a * 0.12, 22, 'Fair value gap');
    }
    if (x.l - y.h > 0.25 * a && !bull(m) && body(m) > 0.55 * a) {
      let open = true;
      for (let j = i + 1; j < n - 1; j++) if (cs[j].c > x.l) { open = false; break; }
      if (open && c.h >= y.h && c.c < (y.h + x.l) / 2 && !bull(c))
        return Q(c, a, 'SELL', Math.max(c.h, x.l) + a * 0.12, 22, 'Fair value gap');
    }
  }
  return null;
}

function sweep(cs, ctx) {
  const a = ctx.atr, n = cs.length, c = cs[n - 1];
  const S = swings(cs.slice(0, -1), 2);
  const r = rng(c);
  const hs = S.H.filter((i) => i > n - 55).map((i) => cs[i].h);
  const ls = S.W.filter((i) => i > n - 55).map((i) => cs[i].l);
  const hi = hs.length ? Math.max(...hs.slice(-3)) : null;
  const lo = ls.length ? Math.min(...ls.slice(-3)) : null;
  if (hi != null && c.h > hi && c.c < hi && !bull(c) && (c.h - Math.max(c.o, c.c)) >= 0.35 * r)
    return Q(c, a, 'SELL', c.h + a * 0.1, 24, 'Liquidity sweep of highs');
  if (lo != null && c.l < lo && c.c > lo && bull(c) && (Math.min(c.o, c.c) - c.l) >= 0.35 * r)
    return Q(c, a, 'BUY', c.l - a * 0.1, 24, 'Liquidity sweep of lows');
  return null;
}

function mss(cs, ctx) {
  const a = ctx.atr, n = cs.length, c = cs[n - 1], p = cs[n - 2];
  const S = swings(cs.slice(0, -1), 2);
  const H = S.H.filter((i) => i > n - 70), W = S.W.filter((i) => i > n - 70);
  if (H.length < 2 || W.length < 2) return null;
  const h1 = H[H.length - 1], h0 = H[H.length - 2], l1 = W[W.length - 1], l0 = W[W.length - 2];
  const disp = body(c) > 0.6 * a;
  if (cs[h1].h < cs[h0].h && disp && bull(c) && c.c > cs[h1].h && p.c <= cs[h1].h)
    return Q(c, a, 'BUY', cs[l1].l - a * 0.12, 26, 'Bullish market structure shift');
  if (cs[l1].l > cs[l0].l && disp && !bull(c) && c.c < cs[l1].l && p.c >= cs[l1].l)
    return Q(c, a, 'SELL', cs[h1].h + a * 0.12, 26, 'Bearish market structure shift');
  return null;
}

function manip(cs, ctx) {
  const a = ctx.atr, n = cs.length, c = cs[n - 1];
  if (n < 24) return null;
  const R = cs.slice(n - 18, n - 4);
  const hi = Math.max(...R.map((x) => x.h)), lo = Math.min(...R.map((x) => x.l)), w = hi - lo;
  if (w > 3.2 * a || w < 0.8 * a) return null;
  const M = cs.slice(n - 4, n - 1);
  const up = Math.max(...M.map((x) => x.h)), dn = Math.min(...M.map((x) => x.l));
  if (up > hi + 0.25 * a && c.c < hi - 0.1 * a && !bull(c) && body(c) > 0.55 * a)
    return Q(c, a, 'SELL', up + a * 0.1, 24, 'Failed break above the range');
  if (dn < lo - 0.25 * a && c.c > lo + 0.1 * a && bull(c) && body(c) > 0.55 * a)
    return Q(c, a, 'BUY', dn - a * 0.1, 24, 'Failed break below the range');
  return null;
}

function accum(cs, ctx) {
  const a = ctx.atr, n = cs.length, c = cs[n - 1];
  if (n < 40) return null;
  const R = cs.slice(n - 16, n - 1);
  const base = atr(cs.slice(0, n - 16)) || a;
  const hi = Math.max(...R.map((x) => x.h)), lo = Math.min(...R.map((x) => x.l));
  const avg = R.reduce((t, x) => t + rng(x), 0) / R.length;
  if (!(avg <= 0.85 * base && (hi - lo) <= 3.2 * base)) return null;
  if (body(c) >= 0.9 * base && bull(c) && c.c > hi) return Q(c, a, 'BUY', (hi + lo) / 2, 22, 'Break after accumulation');
  if (body(c) >= 0.9 * base && !bull(c) && c.c < lo) return Q(c, a, 'SELL', (hi + lo) / 2, 22, 'Break after accumulation');
  return null;
}

function pd(cs, ctx) {
  const a = ctx.atr, n = cs.length, c = cs[n - 1], p = cs[n - 2];
  if (n < 55) return null;
  const W = cs.slice(n - 50, n - 1);
  const hi = Math.max(...W.map((x) => x.h)), lo = Math.min(...W.map((x) => x.l)), span = hi - lo;
  if (span < 5 * a) return null;
  const pos = (c.c - lo) / span, r = rng(c);
  const iH = W.map((x) => x.h).lastIndexOf(hi), iL = W.map((x) => x.l).lastIndexOf(lo);
  if (iL < iH && (c.l - lo) / span <= 0.38 && pos < 0.5 && bull(c) && c.c > p.h && (Math.min(c.o, c.c) - c.l) >= 0.3 * r)
    return Q(c, a, 'BUY', Math.min(c.l, p.l) - a * 0.1, 23, 'Discount rejection');
  if (iH < iL && (c.h - lo) / span >= 0.62 && pos > 0.5 && !bull(c) && c.c < p.l && (c.h - Math.max(c.o, c.c)) >= 0.3 * r)
    return Q(c, a, 'SELL', Math.max(c.h, p.h) + a * 0.1, 23, 'Premium rejection');
  return null;
}

function flow(cs) {
  return cs.map((c) => {
    const r = rng(c);
    const closePos = (c.c - c.l) / r;
    const d = (closePos - 0.5) * 2 * (0.35 + 0.65 * (body(c) / r));
    return d;
  });
}

function stack(cs, ctx) {
  const a = ctx.atr, n = cs.length, c = cs[n - 1];
  if (n < 20) return null;
  const S = cs.slice(-3), F = flow(cs).slice(-3);
  const pc = (x) => (x.c - x.l) / rng(x);
  if (S.every((x, i) => bull(x) && body(x) >= 0.5 * a && pc(x) >= 0.68 && (!i || x.c > S[i - 1].c)) && F.every((d) => d > 0.25))
    return Q(c, a, 'BUY', S[0].l - a * 0.1, 25, 'Stacked buy imbalance');
  if (S.every((x, i) => !bull(x) && body(x) >= 0.5 * a && pc(x) <= 0.32 && (!i || x.c < S[i - 1].c)) && F.every((d) => d < -0.25))
    return Q(c, a, 'SELL', S[0].h + a * 0.1, 25, 'Stacked sell imbalance');
  return null;
}

function absorb(cs, ctx) {
  const a = ctx.atr, n = cs.length, c = cs[n - 1], A = cs[n - 2];
  if (n < 25) return null;
  const prev = cs.slice(n - 22, n - 2), ra = rng(A);
  if (ra < 0.9 * a || body(A) > 0.4 * ra) return null;
  if (A.l <= Math.min(...prev.map((x) => x.l)) + 0.15 * a && (Math.min(A.o, A.c) - A.l) >= 0.45 * ra && bull(c) && c.c > Math.max(A.o, A.c))
    return Q(c, a, 'BUY', A.l - a * 0.1, 24, 'Sellers absorbed at the low');
  if (A.h >= Math.max(...prev.map((x) => x.h)) - 0.15 * a && (A.h - Math.max(A.o, A.c)) >= 0.45 * ra && !bull(c) && c.c < Math.min(A.o, A.c))
    return Q(c, a, 'SELL', A.h + a * 0.1, 24, 'Buyers absorbed at the high');
  return null;
}

function dshift(cs, ctx) {
  const a = ctx.atr, n = cs.length, c = cs[n - 1], p = cs[n - 2];
  if (n < 30) return null;
  const F = flow(cs);
  const P = F.slice(-12, -3).reduce((t, x) => t + x, 0);
  const R = F.slice(-3).reduce((t, x) => t + x, 0);
  const L3 = cs.slice(-3);
  if (P < -1 && R > 1.1 && bull(c) && c.c > p.h)
    return Q(c, a, 'BUY', Math.min(...L3.map((x) => x.l)) - a * 0.1, 24, 'Delta flipped to buyers');
  if (P > 1 && R < -1.1 && !bull(c) && c.c < p.l)
    return Q(c, a, 'SELL', Math.max(...L3.map((x) => x.h)) + a * 0.1, 24, 'Delta flipped to sellers');
  return null;
}

function fail(cs, ctx) {
  const a = ctx.atr, n = cs.length, c = cs[n - 1];
  if (n < 30) return null;
  const prev = cs.slice(n - 24, n - 3);
  const hi = Math.max(...prev.map((x) => x.h)), lo = Math.min(...prev.map((x) => x.l));
  const T = cs.slice(n - 3, n - 1);
  const eh = Math.max(...T.map((x) => x.h)), el = Math.min(...T.map((x) => x.l));
  if (eh > hi + 0.05 * a && c.c < hi && c.c < Math.min(...T.map((x) => x.l)) && !bull(c) && body(c) > 0.45 * a)
    return Q(c, a, 'SELL', eh + a * 0.1, 23, 'Failed auction above the range');
  if (el < lo - 0.05 * a && c.c > lo && c.c > Math.max(...T.map((x) => x.h)) && bull(c) && body(c) > 0.45 * a)
    return Q(c, a, 'BUY', el - a * 0.1, 23, 'Failed auction below the range');
  return null;
}

function balance(cs, ctx) {
  const a = ctx.atr, n = cs.length, c = cs[n - 1];
  if (n < 30) return null;
  const W = cs.slice(n - 26, n - 1);
  const hi = Math.max(...W.map((x) => x.h)), lo = Math.min(...W.map((x) => x.l)), w = hi - lo;
  if (w > 4 * a || w < 1.5 * a) return null;
  const mid = W.filter((x) => x.c > lo + 0.2 * w && x.c < hi - 0.2 * w).length;
  const th = W.filter((x) => x.h >= hi - 0.15 * w).length;
  const tl = W.filter((x) => x.l <= lo + 0.15 * w).length;
  if (mid < W.length * 0.5 || th < 3 || tl < 3) return null;
  const r = rng(c);
  if (c.l <= lo + 0.15 * w && c.c > lo + 0.2 * w && bull(c) && (Math.min(c.o, c.c) - c.l) >= 0.35 * r)
    return Q(c, a, 'BUY', Math.min(c.l, lo) - a * 0.08, 22, 'Rejected the bottom of balance');
  if (c.h >= hi - 0.15 * w && c.c < hi - 0.2 * w && !bull(c) && (c.h - Math.max(c.o, c.c)) >= 0.35 * r)
    return Q(c, a, 'SELL', Math.max(c.h, hi) + a * 0.08, 22, 'Rejected the top of balance');
  return null;
}

function value(cs, ctx) {
  const a = ctx.atr, n = cs.length, c = cs[n - 1], p = cs[n - 2];
  if (n < 50) return null;
  const W = cs.slice(n - 40, n - 1);
  const hi = Math.max(...W.map((x) => x.h)), lo = Math.min(...W.map((x) => x.l));
  const B = 18, bs = (hi - lo) / B;
  if (!(bs > 0)) return null;
  const V = new Array(B).fill(0);
  W.forEach((x) => {
    const i0 = clamp(Math.floor((x.l - lo) / bs), 0, B - 1);
    const i1 = clamp(Math.floor((x.h - lo) / bs), 0, B - 1);
    const w = rng(x) / a / (i1 - i0 + 1);
    for (let i = i0; i <= i1; i++) V[i] += w;
  });
  const tot = V.reduce((s, x) => s + x, 0) || 1;
  let poc = 0;
  V.forEach((x, i) => { if (x > V[poc]) poc = i; });
  let L = poc, H = poc, acc = V[poc];
  while (acc < 0.7 * tot && (L > 0 || H < B - 1)) {
    const dn = L > 0 ? V[L - 1] : -1, up = H < B - 1 ? V[H + 1] : -1;
    if (up >= dn) { H++; acc += V[H]; } else { L--; acc += V[L]; }
  }
  const val = lo + L * bs, vah = lo + (H + 1) * bs;
  if (vah - val < a) return null;
  if (p.c < val - 0.1 * a && c.c > val && bull(c) && body(c) > 0.45 * a)
    return Q(c, a, 'BUY', Math.min(c.l, p.l) - a * 0.1, 24, 'Back inside value, target POC');
  if (p.c > vah + 0.1 * a && c.c < vah && !bull(c) && body(c) > 0.45 * a)
    return Q(c, a, 'SELL', Math.max(c.h, p.h) + a * 0.1, 24, 'Back inside value, target POC');
  return null;
}

function tsm(cs, ctx) {
  const a = ctx.atr, n = cs.length, c = cs[n - 1], p = cs[n - 2];
  if (n < 130) return null;
  const z = [20, 60, 120].map((k) => (c.c - cs[n - 1 - k].c) / (a * Math.sqrt(k)));
  const side = z.every((v) => v > 0.55) ? 'BUY' : z.every((v) => v < -0.55) ? 'SELL' : null;
  if (!side) return null;
  const W = cs.slice(n - 11, n - 1);
  const m = W.reduce((t, x) => t + x.c, 0) / W.length;
  const L = cs.slice(-5);
  const B = side === 'BUY';
  if (B ? !(Math.min(...L.map((x) => x.l)) <= m + 0.35 * a && bull(c) && c.c > p.h)
        : !(Math.max(...L.map((x) => x.h)) >= m - 0.35 * a && !bull(c) && c.c < p.l)) return null;
  const zz = z.reduce((t, v) => t + Math.abs(v), 0) / 3;
  return Q(c, a, side, B ? Math.min(...L.map((x) => x.l)) - a * 0.12 : Math.max(...L.map((x) => x.h)) + a * 0.12, 22 + Math.min(8, zz * 3), '20/60/120 trend, pullback resumed');
}

const ICT = [fvg, sweep, mss, manip, accum, pd];
const OF = [stack, absorb, dshift, fail, balance, value];
const MACRO_RULES = [
  { id: 'tsm', fn: tsm, kind: 'trend', name: 'Time-series momentum' },
  { id: 'mss', fn: mss, kind: 'trend', name: 'Market structure shift' },
  { id: 'fvg', fn: fvg, kind: 'trend', name: 'Fair value gap with trend' },
  { id: 'ob', fn: orderBlock, kind: 'trend', name: 'Order block with trend' },
  { id: 'sweep', fn: sweep, kind: 'fade', name: 'Liquidity sweep fade' },
  { id: 'value', fn: value, kind: 'fade', name: 'Value-area re-entry' },
  { id: 'fail', fn: fail, kind: 'fade', name: 'Failed auction' }
];

function combo(fns, label) {
  return (cs, ctx) => {
    const hits = [];
    for (const fn of fns) {
      const s = fn(cs, ctx);
      if (s && s.side) hits.push(s);
    }
    if (!hits.length) return null;
    const B = hits.filter((h) => h.side === 'BUY'), S = hits.filter((h) => h.side === 'SELL');
    if (B.length === S.length) return { block: label + ' concepts cancelled each other (buy count equals sell count).' };
    const H = B.length > S.length ? B : S;
    const best = H.slice().sort((a, b) => b.q - a.q)[0];
    return { ...best, q: Math.min(40, best.q + 4 * (H.length - 1)), tag: H.map((h) => h.tag).join(' + ') };
  };
}

function slope(series, k) {
  if (!series || series.length < k + 6) return 0;
  const m = (i) => series.slice(i - k, i).reduce((t, x) => t + x.c, 0) / k;
  const n = series.length, a1 = m(n), a0 = m(n - 5), c = series[n - 1].c;
  if (c > a1 && a1 > a0) return 1;
  if (c < a1 && a1 < a0) return -1;
  return 0;
}

function liqReason(ts, cls) {
  const d = new Date(ts * 1000);
  const w = d.getUTCDay();
  const h = d.getUTCHours() + d.getUTCMinutes() / 60;
  if (cls === 'crypto') {
    const mod = h % 8;
    if (mod < 0.12 || mod > 7.88) return 'Crypto funding window (spread and wicks).';
    return null;
  }
  if (w === 6) return 'Saturday. Book is closed.';
  if (w === 0 && h < 21) return 'Sunday open is thin.';
  if (w === 5 && h >= 20) return 'Friday close. Standing down.';
  if (h >= 20.5 && h < 22) return 'New York rollover. Spreads widen hard here.';
  return null;
}

function nfpBlock(ts) {
  const d = new Date(ts * 1000);
  if (d.getUTCDay() !== 5 || d.getUTCDate() > 7) return false;
  const h = d.getUTCHours() + d.getUTCMinutes() / 60;
  return h >= 12.25 && h < 14.25;
}

function replay(fn, cs) {
  const last = cs[cs.length - 1];
  const key = fn.name + '|' + cs.length + '|' + last.t + '|' + last.c.toFixed(4);
  if (REPLAY.has(key)) return REPLAY.get(key);
  let n = 0, R = 0;
  const from = Math.max(130, cs.length - 220);
  for (let i = from; i < cs.length - 6; i += 6) {
    const slice = cs.slice(0, i + 1);
    const a = atr(slice);
    const htf = aggregate(slice, 4);
    const bias = biasOf(htf.length > 30 ? htf : slice);
    let s = null;
    try { s = fn(slice, { atr: a, bias, now: slice[slice.length - 1].t, cls: '', tf: 3600 }); } catch (e) { s = null; }
    if (!s || !s.side) continue;
    const risk = Math.abs(s.entry - s.sl);
    if (!(risk > 0)) continue;
    const dir = s.side === 'BUY' ? 1 : -1;
    let res = 0;
    for (let j = i + 1; j < Math.min(cs.length, i + 40); j++) {
      const x = cs[j];
      const adverse = dir > 0 ? s.entry - x.l : x.h - s.entry;
      const favor = dir > 0 ? x.h - s.entry : s.entry - x.l;
      if (adverse >= risk) { res = -1; break; }
      if (favor >= 2 * risk) { res = 2; break; }
    }
    if (res) { n++; R += res; }
  }
  const out = { n, ex: n ? R / n : 0, sh: R / (n + 8) };
  if (REPLAY.size > 80) REPLAY.clear();
  REPLAY.set(key, out);
  return out;
}

function regimeOk(kind, z) {
  if (kind === 'trend') return z >= 1.25;
  return z <= -1.25;
}

function runMacro(cs, ctx) {
  const gates = [];
  const mark = (name, ok, detail) => gates.push({ name, ok, detail });
  const a = ctx.atr;
  const vr = vratio(cs);
  if (ctx.tf < 3600) {
    mark('Timeframe', false, 'Macro only clears 1h, 4h, 1D and 1W. Faster charts stay in the tactical book.');
    return { signal: null, ghost: null, score: 0, bias: ctx.bias, drops: [gates[0].detail], gates, vr };
  }
  mark('Timeframe', true, 'Hourly or higher.');

  const dayF = Math.max(1, Math.round(86400 / ctx.tf));
  const daily = aggregate(cs, dayF);
  const dayT = slope(daily, daily.length >= 26 ? 20 : 10);
  const weekly = aggregate(daily, 5);
  const weekT = weekly.length >= 16 ? slope(weekly, 8) : 0;
  mark('Daily trend sample', daily.length >= 16, daily.length >= 16 ? 'Enough daily bars to vote.' : 'Not enough daily bars on this feed.');

  const liq = liqReason(ctx.execNow || ctx.now, ctx.cls);
  mark('Liquid hours', !liq, liq || 'Outside the rollover and the weekly gap.');
  const news = nfpBlock(ctx.execNow || ctx.now);
  mark('Event blackout', !news, news ? 'First-Friday USD window 12:15–14:15 UTC.' : 'No built-in high-impact window.');

  const vol = avgRange(cs.slice(-14)) / (avgRange(cs.slice(-114)) || 1e-12);
  const volOk = vol >= 0.75 && vol <= 1.85;
  mark('Volatility band', volOk, 'Realized vol ' + vol.toFixed(2) + '× vs the last 100 bars. Band is 0.75–1.85.');

  const bookN = (ctx.openBuckets && ctx.openBuckets[ctx.bucket]) || 0;
  mark('Book concentration', bookN < 2, bookN < 2 ? 'This risk bucket is not crowded.' : 'Two open risks already share this bucket.');

  if (!gates.every((g) => g.ok)) {
    return { signal: null, ghost: null, score: 0, bias: ctx.bias, drops: gates.filter((g) => !g.ok).map((g) => g.detail), gates, vr, vol };
  }

  let best = null;
  const near = [];
  for (const rule of MACRO_RULES) {
    let found = null;
    for (let age = 0; age <= 2; age++) {
      const p = age ? cs.slice(0, -age) : cs;
      const aa = atr(p);
      const htf = aggregate(p, 4);
      const bias = biasOf(htf.length > 30 ? htf : p);
      let s = null;
      try { s = rule.fn(p, { ...ctx, atr: aa, bias }); } catch (e) { s = null; }
      if (s && s.side) { found = { s, age, a: aa, bias }; break; }
    }
    if (!found) { near.push(rule.name + ': no fresh trigger'); continue; }
    const reasons = [];
    if (!regimeOk(rule.kind, vr.z)) reasons.push('variance-ratio z ' + vr.z.toFixed(2) + ' does not fit a ' + rule.kind + ' rule (need ' + (rule.kind === 'trend' ? '≥ 1.25' : '≤ −1.25') + ')');
    const dir = found.s.side === 'BUY' ? 1 : -1;
    if (dayT === -dir) reasons.push('daily trend opposes');
    if (weekT === -dir) reasons.push('weekly trend opposes');
    if (dayT !== dir && found.bias !== dir) reasons.push('neither the daily trend nor the 4× bias agrees');
    const ext = Math.abs(cs[cs.length - 1].c - found.s.entry);
    if (ext > 0.55 * a) reasons.push('price already ran ' + (ext / a).toFixed(2) + ' ATR from the trigger');
    const risk = Math.abs(found.s.entry - found.s.sl);
    if (risk < 0.35 * a || risk > 2.2 * a) reasons.push('stop is ' + (risk / a).toFixed(2) + ' ATR (allowed 0.35–2.2)');
    if (found.age > 2) reasons.push('trigger is stale');
    const ev = replay(rule.fn, cs);
    if (ev.n < 8) reasons.push('walk-forward only ' + ev.n + ' trades — sample too thin, dropped');
    else if (ev.sh < 0.08) reasons.push('walk-forward shrunk expectancy ' + ev.sh.toFixed(2) + 'R is below 0.08R');
    let agree = 2.4;
    let oppose = 0;
    if (dayT === dir) agree += 2; else if (dayT === -dir) oppose += 2;
    if (weekT === dir) agree += 1.5; else if (weekT === -dir) oppose += 1.5;
    if (found.bias === dir) agree += 1; else if (found.bias === -dir) oppose += 1;
    if (regimeOk(rule.kind, vr.z)) agree += 1.5;
    if (agree < 6.5) reasons.push('confluence ' + agree.toFixed(1) + ' is under 6.5');
    if (oppose > 0.75) reasons.push('opposing weight ' + oppose.toFixed(1) + ' is over 0.75');
    if (reasons.length) {
      near.push(rule.name + ' blocked: ' + reasons[0]);
      continue;
    }
    const scalar = clamp(1 / vol, 0.45, 1);
    let score = 74 + Math.min(10, (agree - 6.5) * 3) + (ev.sh > 0.25 ? 5 : 0) + (vol >= 0.9 && vol <= 1.35 ? 3 : 0);
    score = Math.round(clamp(score, 78, 94));
    if (score < 82) { near.push(rule.name + ' score ' + score + ' under 82'); continue; }
    const tps = buildTargets(found.s.side, cs[cs.length - 1].c, found.s.sl, cs, a);
    const pack = {
      ...found.s,
      entry: cs[cs.length - 1].c,
      tps,
      score,
      kind: 'macro',
      tag: 'ALLADINN · ' + found.s.tag,
      age: found.age,
      scalar,
      evidence: ev,
      agree,
      oppose,
      vr, vol, dayT, weekT
    };
    if (!best || pack.score > best.score) best = pack;
  }

  mark('Regime fit', !!best, best ? ('Cleared on z ' + vr.z.toFixed(2)) : ('z ' + vr.z.toFixed(2) + ' or the rule did not fit'));
  mark('Walk-forward', !!best, best ? (best.evidence.n + ' trades, shrunk ' + best.evidence.sh.toFixed(2) + 'R') : 'No rule survived the replay cut');
  mark('Confluence floor', !!best, best ? (best.agree.toFixed(1) + ' for / ' + best.oppose.toFixed(1) + ' against') : 'No pack reached 6.5 for and ≤ 0.75 against');
  mark('Score floor 82', !!best, best ? ('Cleared at ' + best.score) : 'Nothing reached 82');

  if (!best) {
    return { signal: null, ghost: null, score: 0, bias: ctx.bias, drops: near.slice(0, 6), gates, vr, vol, dayT, weekT };
  }
  return { signal: best, ghost: null, score: best.score, bias: ctx.bias, drops: [], gates, vr, vol, dayT, weekT };
}

export function buildTargets(side, entry, sl, cs, a) {
  const risk = Math.abs(entry - sl);
  if (!(risk > 0)) return [];
  const dir = side === 'BUY' ? 1 : -1;
  const { H, W } = swings(cs, 2);
  const levels = [];
  if (dir > 0) H.forEach((i) => levels.push({ px: cs[i].h, why: 'swing high' }));
  else W.forEach((i) => levels.push({ px: cs[i].l, why: 'swing low' }));
  const struct = levels
    .map((L) => ({ ...L, r: dir * (L.px - entry) / risk }))
    .filter((L) => L.r >= 0.75 && L.r <= 4.2)
    .sort((a, b) => a.r - b.r);
  const pick = (minR, fallback) => {
    const hit = struct.find((L) => L.r >= minR && L.r <= fallback + 0.9);
    if (hit) {
      const r = +(hit.r * 0.97).toFixed(2);
      return { r, px: entry + dir * risk * r, why: hit.why + ', just before the pool' };
    }
    return { r: fallback, px: entry + dir * risk * fallback, why: fallback.toFixed(1) + 'R measured move' };
  };
  const tp1 = pick(0.85, 0.9);
  const tp2 = pick(Math.max(1.4, tp1.r + 0.35), 1.6);
  const tp3 = pick(Math.max(2.15, tp2.r + 0.45), 2.5);
  return [
    { ...tp1, pct: 40, note: 'Sell 40%. Move the stop to entry.' },
    { ...tp2, pct: 40, note: 'Sell 40%. Trail the rest under the last swing.' },
    { ...tp3, pct: 20, note: 'Runner. Scratch if 8 bars pass and the trade is under 0.3R.' }
  ];
}

const FN = {
  macro: runMacro,
  conf: confluence,
  msnr: msnrOb,
  ob: orderBlock,
  ict: combo(ICT, 'ICT'),
  fvg, sweep, mss, manip, accum, pd,
  of: combo(OF, 'Orderflow'),
  stack, absorb, dshift, fail, balance, value
};

export const BOOK = [
  { group: 'ALLADINN macro', items: [
    ['macro', 'Macro desk (strict)', 'Clears only on 1h and higher. A rule must fit the variance-ratio regime (z ≥ 1.25 to trend, z ≤ −1.25 to fade), agree with the daily trend or the 4× bias, keep weekly from opposing, stay inside 0.55 ATR of the trigger, use a 0.35–2.2 ATR stop, show 8+ walk-forward trades with shrunk expectancy ≥ 0.08R, score at least 6.5 for and at most 0.75 against, and print 82+. Size is cut when volatility is hot, and never levered up.']
  ]},
  { group: 'Structure', items: [
    ['conf', 'Confluence · MSNR + OB', 'Higher-timeframe bias must exist and agree. An order block is retested on a fresh MSNR level. Metals only 13:00–17:00 UTC.'],
    ['msnr', 'MSNR + order block', 'Same order-block retest, but the level must be a fresh close-price peak or trough.'],
    ['ob', 'Order block', 'The last opposite candle before displacement is retested and holds.']
  ]},
  { group: 'ICT', items: [
    ['ict', 'ICT concepts (all six)', 'Any of the six can fire. Two on the same side add weight. A tie cancels.'],
    ['fvg', 'Fair value gap', 'Return into an open three-candle gap and close back through its midpoint.'],
    ['sweep', 'Liquidity sweep', 'Wick through a recent swing, close back inside.'],
    ['mss', 'Market structure shift', 'Displacement close through the last lower-high or higher-low.'],
    ['manip', 'Manipulation', 'A quiet range breaks one way and the break fails.'],
    ['accum', 'Accumulation', 'A volatility squeeze, then a strong close out of it.'],
    ['pd', 'Premium and discount', 'Rejection in the cheap half to buy, or the expensive half to sell.']
  ]},
  { group: 'Orderflow (estimated)', items: [
    ['of', 'Orderflow concepts (all six)', 'The feed has no real volume. Delta is estimated from where the candle closed inside its range.'],
    ['stack', 'Stacked imbalance', 'Three candles closing on their highs or lows with delta all one way.'],
    ['absorb', 'Absorption', 'Wide range, small body, long wick at a swing, then a confirming candle.'],
    ['dshift', 'Delta shift', 'One-sided delta flips and price breaks the prior candle.'],
    ['fail', 'Failed auction', 'Two candles probe outside a range and the next close comes back in.'],
    ['balance', 'Balance', 'Fade a rejection at the edge of a rotation, back toward the middle.'],
    ['value', 'Value area', 'Price closes back inside the 70% value area. Target is the point of control.']
  ]}
];

function tactical(cs, ctx, id) {
  const fn = FN[id];
  const raw = fn(cs, ctx);
  if (raw && raw.block) return { signal: null, ghost: null, score: 0, bias: ctx.bias, drops: [raw.block], gates: [] };
  if (!raw || !raw.side) return { signal: null, ghost: null, score: 0, bias: ctx.bias, drops: ['No trigger on the last closed candle.'], gates: [] };
  const drops = [];
  if (ctx.bias && ((raw.side === 'BUY' && ctx.bias < 0) || (raw.side === 'SELL' && ctx.bias > 0)))
    drops.push('Blocked: the idea fights the higher-timeframe bias.');
  const tps = buildTargets(raw.side, raw.entry, raw.sl, cs, ctx.atr);
  let score = 38 + raw.q;
  if ((raw.side === 'BUY' && ctx.bias > 0) || (raw.side === 'SELL' && ctx.bias < 0)) score += 12;
  if (!ctx.bias) score -= 6;
  if (tps[1] && tps[1].r >= 1.5) score += 5;
  const risk = Math.abs(raw.entry - raw.sl);
  if (risk < 0.2 * ctx.atr || risk > 3.4 * ctx.atr) drops.push('Blocked: stop is outside 0.2–3.4 ATR.');
  score = Math.round(clamp(score, 1, 92));
  if (score < 64) drops.push('Blocked: score ' + score + ' is under 64.');
  const ghost = { ...raw, tps, score, kind: 'tactical' };
  if (drops.length) return { signal: null, ghost, score, bias: ctx.bias, drops, gates: [] };
  return { signal: { ...ghost, scalar: 1 }, ghost: null, score, bias: ctx.bias, drops: [], gates: [] };
}

export function analyze(candles, stratId, extra) {
  const cs = candles.slice(0, -1);
  if (cs.length < 80) return { signal: null, ghost: null, score: 0, bias: 0, drops: ['Waiting for at least 80 closed candles.'], gates: [] };
  const htf = extra.tf >= 86400 ? cs : aggregate(cs, 4);
  const ctx = {
    atr: atr(cs),
    bias: biasOf(htf.length > 30 ? htf : cs),
    sym: extra.sym,
    tf: extra.tf,
    cls: extra.cls,
    bucket: extra.bucket,
    now: candles[candles.length - 1].t,
    execNow: Math.floor(Date.now() / 1000),
    openBuckets: extra.openBuckets || {}
  };
  if (!(ctx.atr > 0)) return { signal: null, ghost: null, score: 0, bias: 0, drops: ['ATR is flat.'], gates: [] };
  if (stratId === 'macro') return runMacro(cs, ctx);
  return tactical(cs, ctx, stratId);
}

function hash(str) {
  let s = 2166136261;
  for (let i = 0; i < str.length; i++) s = Math.imul(s ^ str.charCodeAt(i), 16777619);
  return s >>> 0;
}

export function simulate(sym, tf, n = 480) {
  let s = hash(sym.id + '|' + tf + '|' + Math.floor(Date.now() / 3600000));
  const rnd = () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; };
  const regime = rnd();
  let p = sym.seed * (0.99 + rnd() * 0.02);
  const vol = sym.cls === 'forex' ? 0.00045 : sym.cls === 'metal' ? 0.0014 : 0.0048;
  const t0 = Math.floor(Date.now() / tf) * tf - (n - 1) * tf;
  const out = [];
  let drift = regime > 0.42 ? vol * 0.42 : regime < 0.18 ? -vol * 0.08 : 0;
  for (let i = 0; i < n; i++) {
    if (i % 64 === 0 && regime > 0.42) drift = vol * (0.22 + rnd() * 0.28);
    const o = p;
    let c = o * (1 + drift + (rnd() - 0.5) * vol * 1.7);
    let h = Math.max(o, c) * (1 + rnd() * vol * 0.8);
    let l = Math.min(o, c) * (1 - rnd() * vol * 0.8);
    if (regime > 0.42 && i === n - 2) {
      l = o * (1 - vol * 2.4);
      c = o * (1 + vol * 0.55);
      h = Math.max(o, c) * (1 + vol * 0.25);
    }
    if (regime <= 0.18 && i === n - 2) {
      l = Math.min(l, o * (1 - vol * 5));
      c = o * (1 + vol * 0.7);
      h = Math.max(h, o);
    }
    if (c <= 0) c = o;
    p = c;
    out.push({ t: t0 + i * tf, o, h: Math.max(h, o, c), l: Math.min(l, o, c), c, v: Math.round(80 + rnd() * 1400) });
  }
  return out;
}

export async function loadCandles(sym, tf) {
  const spec = TFS.find((t) => t.sec === tf) || TFS[4];
  const url = 'https://api.binance.com/api/v3/klines?symbol=' + sym.id + '&interval=' + spec.bin + '&limit=500';
  const ac = new AbortController();
  const to = setTimeout(() => ac.abort(), 8000);
  try {
    const r = await fetch(url, { signal: ac.signal });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const j = await r.json();
    if (!Array.isArray(j) || j.length < 80) throw new Error('short book');
    const candles = j.map((k) => ({ t: Math.floor(+k[0] / 1000), o: +k[1], h: +k[2], l: +k[3], c: +k[4], v: +k[5] }));
    return { candles, live: true };
  } catch (e) {
    return { candles: simulate(sym, tf, 480), live: false, error: (e && e.message) || 'offline' };
  } finally {
    clearTimeout(to);
  }
}

export function money(v) {
  const n = Math.abs(v);
  const s = n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return (v < 0 ? '−' : '') + '$' + s;
}

export function fmtPx(v, dec) {
  if (v == null || Number.isNaN(v)) return '—';
  return Number(v).toLocaleString(undefined, { minimumFractionDigits: dec, maximumFractionDigits: dec });
}
