/* TradingView-style canvas: candles, volume, crosshair, signal lines. */

function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

export function mountChart(canvas) {
  const ctx = canvas.getContext('2d');
  const st = {
    candles: [],
    dec: 2,
    count: 90,
    offset: 0,
    cross: true,
    pointer: null,
    signal: null,
    ghost: null,
    drag: null
  };

  function cssSize() {
    const r = canvas.getBoundingClientRect();
    return { w: Math.max(10, r.width), h: Math.max(10, r.height) };
  }

  function resize() {
    const { w, h } = cssSize();
    const d = Math.min(2, window.devicePixelRatio || 1);
    canvas.width = Math.round(w * d);
    canvas.height = Math.round(h * d);
    ctx.setTransform(d, 0, 0, d, 0, 0);
    draw();
  }

  function windowBars() {
    const n = st.candles.length;
    const count = clamp(Math.round(st.count), 24, Math.max(24, n));
    const end = clamp(n - st.offset, count, n);
    const start = Math.max(0, end - count);
    return { start, end, count: end - start };
  }

  function layout(w, h) {
    const padR = 72, padB = 26, padT = 12, padL = 8;
    const volH = Math.max(36, Math.round(h * 0.16));
    const plot = { x: padL, y: padT, w: w - padR - padL, h: h - padB - volH - padT - 8 };
    const vol = { x: padL, y: plot.y + plot.h + 8, w: plot.w, h: volH - 4 };
    return { plot, vol, scaleX: w - padR };
  }

  function draw() {
    const { w, h } = cssSize();
    ctx.clearRect(0, 0, w, h);
    const cs = st.candles;
    if (cs.length < 2) {
      ctx.fillStyle = '#9a9286';
      ctx.font = '13px Manrope, sans-serif';
      ctx.fillText('Waiting for candles…', 16, 28);
      return;
    }
    const { start, end, count } = windowBars();
    const view = cs.slice(start, end);
    const L = layout(w, h);
    let lo = Math.min(...view.map((c) => c.l));
    let hi = Math.max(...view.map((c) => c.h));
    const lines = [];
    const sig = st.signal || st.ghost;
    if (sig) {
      lines.push(sig.entry, sig.sl);
      (sig.tps || []).forEach((t) => lines.push(t.px));
    }
    lines.forEach((p) => { if (p > hi) hi = p; if (p < lo) lo = p; });
    const pad = (hi - lo) * 0.08 || Math.abs(hi) * 0.002 || 1;
    lo -= pad; hi += pad;
    const yOf = (p) => L.plot.y + (hi - p) / (hi - lo) * L.plot.h;
    const bw = L.plot.w / count;
    const vmax = Math.max(...view.map((c) => c.v || 0), 1);

    ctx.strokeStyle = 'rgba(255,226,190,.06)';
    ctx.lineWidth = 1;
    ctx.font = '11px "IBM Plex Mono", ui-monospace, monospace';
    for (let i = 0; i < 5; i++) {
      const p = lo + (hi - lo) * (i / 4);
      const y = yOf(p);
      ctx.beginPath();
      ctx.moveTo(L.plot.x, y);
      ctx.lineTo(L.plot.x + L.plot.w, y);
      ctx.stroke();
      ctx.fillStyle = 'rgba(243,230,207,.55)';
      ctx.textAlign = 'left';
      ctx.fillText(format(p, st.dec), L.scaleX + 8, y + 4);
    }

    view.forEach((c, i) => {
      const x = L.plot.x + i * bw;
      const cx = x + bw / 2;
      const up = c.c >= c.o;
      const col = up ? '#3ee0a2' : '#ff5d73';
      ctx.strokeStyle = col;
      ctx.fillStyle = col;
      ctx.beginPath();
      ctx.moveTo(cx, yOf(c.h));
      ctx.lineTo(cx, yOf(c.l));
      ctx.stroke();
      const y1 = yOf(Math.max(c.o, c.c));
      const y2 = yOf(Math.min(c.o, c.c));
      const bh = Math.max(1, y2 - y1);
      const gap = Math.max(1, bw * 0.22);
      ctx.globalAlpha = up ? 0.95 : 0.9;
      ctx.fillRect(x + gap / 2, y1, Math.max(1, bw - gap), bh);
      ctx.globalAlpha = 1;
      const vh = (c.v || 0) / vmax * L.vol.h;
      ctx.globalAlpha = 0.55;
      ctx.fillRect(x + gap / 2, L.vol.y + L.vol.h - vh, Math.max(1, bw - gap), vh);
      ctx.globalAlpha = 1;
    });

    const last = cs[cs.length - 1];
    const ly = yOf(last.c);
    if (ly > L.plot.y && ly < L.plot.y + L.plot.h) {
      ctx.setLineDash([4, 4]);
      ctx.strokeStyle = last.c >= last.o ? 'rgba(62,224,162,.8)' : 'rgba(255,93,115,.85)';
      ctx.beginPath();
      ctx.moveTo(L.plot.x, ly);
      ctx.lineTo(L.plot.x + L.plot.w, ly);
      ctx.stroke();
      ctx.setLineDash([]);
      const tag = format(last.c, st.dec);
      const tw = ctx.measureText(tag).width + 12;
      ctx.fillStyle = last.c >= last.o ? '#14684d' : '#7a2434';
      roundRect(ctx, L.scaleX + 4, ly - 9, tw, 18, 5);
      ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.fillText(tag, L.scaleX + 10, ly + 4);
    }

    drawLevel(sig && st.signal ? sig : null, st.ghost && !st.signal ? st.ghost : null, yOf, L);

    const ticks = 5;
    ctx.fillStyle = 'rgba(243,230,207,.45)';
    ctx.textAlign = 'left';
    for (let i = 0; i < ticks; i++) {
      const idx = Math.round(start + (count - 1) * (i / (ticks - 1)));
      const c = cs[clamp(idx, 0, cs.length - 1)];
      const x = L.plot.x + (idx - start) * bw;
      ctx.fillText(timeLabel(c.t, cs), x, h - 8);
    }

    if (st.cross && st.pointer) {
      const px = clamp(st.pointer.x, L.plot.x, L.plot.x + L.plot.w);
      const py = clamp(st.pointer.y, L.plot.y, L.plot.y + L.plot.h);
      const i = clamp(Math.floor((px - L.plot.x) / bw), 0, view.length - 1);
      const c = view[i];
      ctx.save();
      ctx.strokeStyle = 'rgba(232,177,90,.65)';
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      ctx.moveTo(L.plot.x + i * bw + bw / 2, L.plot.y);
      ctx.lineTo(L.plot.x + i * bw + bw / 2, L.plot.y + L.plot.h);
      ctx.moveTo(L.plot.x, py);
      ctx.lineTo(L.plot.x + L.plot.w, py);
      ctx.stroke();
      ctx.restore();
      const price = hi - (py - L.plot.y) / L.plot.h * (hi - lo);
      ctx.fillStyle = '#e8b15a';
      ctx.fillRect(L.scaleX + 4, py - 9, 64, 18);
      ctx.fillStyle = '#1a1204';
      ctx.fillText(format(price, st.dec), L.scaleX + 8, py + 4);
      if (c) st._ohlc = c;
    } else st._ohlc = view[view.length - 1];

    return st._ohlc;
  }

  function drawLevel(live, ghost, yOf, L) {
    const drawOne = (sig, alpha, dash) => {
      if (!sig) return;
      const rows = [
        [sig.entry, 'ENTRY', '124, 168, 255'],
        [sig.sl, 'STOP', '255, 93, 115']
      ];
      (sig.tps || []).forEach((t, i) => rows.push([t.px, 'TP' + (i + 1) + '  ' + t.r + 'R', '62, 224, 162']));
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.setLineDash(dash);
      ctx.font = '10px "IBM Plex Mono", ui-monospace, monospace';
      rows.forEach(([px, label, col]) => {
        const y = yOf(px);
        if (y < L.plot.y - 4 || y > L.plot.y + L.plot.h + 4) return;
        ctx.strokeStyle = 'rgb(' + col + ')';
        ctx.beginPath();
        ctx.moveTo(L.plot.x, y);
        ctx.lineTo(L.plot.x + L.plot.w, y);
        ctx.stroke();
        ctx.fillStyle = 'rgb(' + col + ')';
        ctx.textAlign = 'right';
        ctx.fillText(label, L.plot.x + L.plot.w - 6, y - 3);
      });
      ctx.restore();
    };
    drawOne(ghost, 0.35, [2, 5]);
    drawOne(live, 0.9, [5, 4]);
  }

  canvas.addEventListener('wheel', (e) => {
    e.preventDefault();
    const next = st.count * (e.deltaY > 0 ? 1.12 : 0.88);
    st.count = clamp(next, 24, 420);
    draw();
    emit();
  }, { passive: false });

  canvas.addEventListener('pointerdown', (e) => {
    st.drag = { x: e.clientX, offset: st.offset };
    canvas.setPointerCapture(e.pointerId);
  });
  canvas.addEventListener('pointermove', (e) => {
    const r = canvas.getBoundingClientRect();
    st.pointer = { x: e.clientX - r.left, y: e.clientY - r.top };
    if (st.drag) {
      const { w } = cssSize();
      const bw = (w - 80) / clamp(st.count, 24, 999);
      st.offset = clamp(Math.round(st.drag.offset + (e.clientX - st.drag.x) / bw), 0, Math.max(0, st.candles.length - 24));
    }
    draw();
    emit();
  });
  const endDrag = () => { st.drag = null; };
  canvas.addEventListener('pointerup', endDrag);
  canvas.addEventListener('pointercancel', endDrag);
  canvas.addEventListener('pointerleave', () => {
    if (!st.drag) { st.pointer = null; draw(); emit(); }
  });

  function emit() {
    if (st.onLegend) st.onLegend(st._ohlc || null);
  }

  function zoom(dir) {
    st.count = clamp(st.count * (dir > 0 ? 0.82 : 1.22), 24, 420);
    draw(); emit();
  }

  return {
    setData(candles, dec) { st.candles = candles || []; st.dec = dec; draw(); emit(); },
    setSignal(signal, ghost) { st.signal = signal; st.ghost = ghost; draw(); },
    zoom,
    reset() { st.count = 90; st.offset = 0; draw(); emit(); },
    setCross(on) { st.cross = on; if (!on) st.pointer = null; draw(); emit(); },
    resize,
    onLegend: null
  };
}

function format(v, dec) {
  return Number(v).toLocaleString(undefined, { minimumFractionDigits: Math.min(dec, 2), maximumFractionDigits: dec });
}

function timeLabel(t, cs) {
  const d = new Date(t * 1000);
  const step = cs.length > 1 ? Math.abs(cs[1].t - cs[0].t) : 3600;
  if (step >= 86400) return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', timeZone: 'UTC' });
  return d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'UTC' });
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}
